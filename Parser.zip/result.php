<?php
$dirname = dirname(__FILE__);
$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;


require_once( $root . "wp-config.php" );


$servername =DB_HOST;
$username =DB_USER;
$password =DB_PASSWORD;
$dbname =DB_NAME;



    if(isset($_POST['link'])){

include_once('simple_html_dom.php');
        $url=$_POST['link'];

        switch($_POST['taskOption']){
case 'img':

     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);

    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('img');

        foreach ($tags as $tag) {
    
        /*    echo "<pre>";
                print_r($tag->getAttribute('src'));
            echo "<pre>";
        */
            $xx=$tag->getAttribute('src');
echo $xx."<br>";echo $url;

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url',' $xx', 'null','null', 'null', 'null','null', 'null', 'null','null', 'null')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;

  }

   } else {
     echo "task option is required";
     exit; 
   }
break;
case 'p':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);
    //echo $html;

    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    
    $tags = $doc->getElementsByTagName('p');

        foreach ($tags as $tag) {
      
          /*  echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";*/
$xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url','null', '$xx','null', 'null', 'null','null', 'null', 'null','null', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
$conn = null;
         }

   } else {
     echo "task option is required";
     exit; 
       }

break;

case 'h1':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";
        $html = file_get_contents($url);

    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h1');

        foreach ($tags as $tag) {
        
        /*/
            echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";
*/

$xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url','null', 'null','null', '$xx', 'null','null', 'null', 'null','null', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



         }

   } else {
     echo "task option is required";
     exit; 
   }

break;
case 'h2':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h2');

        foreach ($tags as $tag) {
       
         /*   echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";*/
            $xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url','null', 'null','null', 'null', '$xx','null', 'null', 'null','null', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



         }

   } else {
     echo "task option is required";
     exit; 
   }

break;
case 'h3':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";
    //   print_r($x);
        $html = file_get_contents($url);
    //echo $html;

    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h3');

    foreach ($tags as $tag) {
         
          /*      echo "<pre>";
                    print_r($tag->nodeValue);
                echo "<pre>";*/
    $xx=$tag->nodeValue;
    try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
            VALUES ('$url','null', 'null','null', 'null', 'null','$xx', 'null', 'null','null', 'null')";

            $conn->exec($sql);
            echo "New record created successfully";
        }
    catch(PDOException $e)
        {
         echo $sql . "<br>" . $e->getMessage();
        }

    $conn = null;



}

   } else {
     echo "task option is required";
     exit; 
   }

break;
case 'h4':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
         $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h4');

        foreach ($tags as $tag) {
      
       /*echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";*/

$xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url','null', 'null','null', 'null', 'null','null', '$xx', 'null','null', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



         }

   } else {
     echo "task option is required";
     exit; 
   }

break;


case 'h5':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h5');

        foreach ($tags as $tag) {
      

        /*
            echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";*/
$xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url','null', 'null','null', 'null', 'null','null', 'null', '$xx','null', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;


         }

   } else {
     echo "task option is required";
     exit; 
   }

break;
case 'h6':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('h6');

        foreach ($tags as $tag) {
            
           /* echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";*/
            $xx=$tag->nodeValue;

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url',' null', 'null','null', 'null', 'null','null', 'null', 'null','$xx', 'null')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



         }

   } else {
     echo "task option is required";
     exit; 
   }
case 'span':
    
     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('span');

        foreach ($tags as $tag) {
      

            echo "<pre>";
                print_r($tag->nodeValue);
            echo "<pre>";
            $xx=$tag->nodeValue;
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url',' null', 'null','null', 'null', 'null','null', 'null', 'null','null', '$xx')";

    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;

         }

   } else {
     echo "task option is required";
     exit; 
   }

break;
case 'a':

     $option = isset($_POST['taskOption']) ? $_POST['taskOption'] : false;
   if ($option) {
   $x=htmlentities($_POST['taskOption'], ENT_QUOTES, "UTF-8")."<br>";

        $html = file_get_contents($url);


    $doc = new DOMDocument();
    @$doc->loadHTML($html);

    $tags = $doc->getElementsByTagName('a');

        foreach ($tags as $tag) {
        //        echo "<a href='".$tag->getAttribute('src')."'><img src=".$tag->getAttribute('src')." style='width:150px;displai:inline-block;height:150px'></a><br>";
        //
        
           /*     $xx="<a href=".$tag->getAttribute('href').">".$tag->getAttribute('href')."</a>";
           */
$xx=$tag->getAttribute('href');
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO sul_parser (url, img, p, a, h1, h2, h3, h4, h5, h6, span)
    VALUES ('$url',' null', 'null','$xx', 'null', 'null','null', 'null', 'null','null', 'null')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



         }

   } else {
     echo "task option is required";
     exit; 
   }

break;
default:
    }





}
