<?php
   /*
   Plugin Name: Parser 
   description:Parser plugin by Svetlanna Sultanyan
   Version: 1
   Author: Svetlanna Sultanyan

   */
   function index(){

      echo "555";
   }

   function parser_activate() {

global $wpdb;
$table_name='sul_parser';
$charset_collate = $wpdb->get_charset_collate();
   $sql = "CREATE TABLE $table_name (
     id mediumint(9) NOT NULL AUTO_INCREMENT,
     url varchar(255),
     img varchar(255),
     p varchar(255),
     a varchar(255),
     h1 varchar(255),
     h2 varchar(255),
     h3 varchar(255),
     h4 varchar(255),
     h5 varchar(255),
     h6 varchar(255),
     span text,

     PRIMARY KEY  (id)
   ) $charset_collate;";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

   dbDelta( $sql );
}
register_activation_hook( __FILE__, 'parser_activate' );

add_action('admin_menu', 'mt_add_pages');



// action function for above hook
function mt_add_pages() {

    // Add a new top-level menu (ill-advised):
    add_menu_page(__('Parser','menu-test'), __('Parser','menu-test'), 'manage_options', 'manage-Parsers', 'Parser_page' );

    // Add a submenu to the custom top-level menu:
    add_submenu_page('Parser', __('menu-test'), __('menu-test'), 'manage_options', 'add-Parser', 'add_new_Parser_page');

}

// mt_toplevel_page() displays the page content for the custom Test Toplevel menu
function Parser_page() {
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
    echo "<br/>";
 

    echo "<h2>" . __( 'Manage Parser', 'menu-test' ) . "</h2>";

    include_once 'parser.php';
}

// mt_sublevel_page() displays the page content for the first submenu
// of the custom Test Toplevel menu
function add_new_Parser_page() {
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
    echo "<br/>";

    include_once 'parser.php';
}