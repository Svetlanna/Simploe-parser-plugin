<?php  

$dirname = dirname(__FILE__);
$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;
// if $root is not correct, provide a static path then, $root = '/path/to/root/dir'
// assuming constants are ready (wp is configured), let's get them.
require_once( $root . "wp-config.php" );


$connect = mysqli_connect(DB_HOST, DB_USER,DB_PASSWORD, DB_NAME);
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM sul_parser";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th>url</th>  
                         <th>img</th>  
                         <th>p</th>  
       <th>a</th>
       <th>h1</th>
       <th>h2</th>
       <th>h3</th>
       <th>h4</th>
       <th>h5</th>
       <th>h6</th>
       <th>span</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["url"].'</td>  
         <td>'.$row["img"].'</td>  
         <td>'.$row["p"].'</td>  
         <td>'.$row["a"].'</td>  
         <td>'.$row["h1"].'</td>
         <td>'.$row["h2"].'</td>
         <td>'.$row["h3"].'</td>
         <td>'.$row["h4"].'</td>
         <td>'.$row["h5"].'</td>
         <td>'.$row["h6"].'</td>
         <td>'.$row["span"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Svetlanna_task_plugin.xls');
  echo $output;
 }
}
?>