<?php

$dirname = dirname(__FILE__);
$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;
// if $root is not correct, provide a static path then, $root = '/path/to/root/dir'
// assuming constants are ready (wp is configured), let's get them.
require_once( $root . "wp-config.php" );


$connect = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$sql = "SELECT * FROM sul_parser";  
$result = mysqli_query($connect, $sql);


?>
<form action="<?=plugin_dir_url(__FILE__)?>result.php" method='post'>
	<input type='text' name='link' placeholder='Add url'>
  <select name="taskOption">
    <option value="img">  I WANT TO PARSING THE PHOTO-s</option>
    <option value="p">  I WANT TO PARSING THE  P-s</option>
    <option value="h1">  I WANT TO PARSING THE h1-s</option>
    <option value="h2">  I WANT TO PARSING THE h2-s</option>
    <option value="h3">  I WANT TO PARSING THE  h3-s</option>
    <option value="h4">  I WANT TO PARSING THE  h4-s</option>
    <option value="h5"> I WANT TO PARSING THE h5-s</option>
    <option value="h6">  I WANT TO PARSING THE  h6-s</option>
    <option value="span">  I WANT TO PARSING THE span-s</option>
    <option value="a">   I WANT TO PARSING THE  href-s</option>
  </select>
	<button>search</button>
</form>
<form method='post' action=''>
<button name='zz'>Download parser Table</button>
</form>
<?php
if(isset($_POST['zz'])){print($wpml);

    ?><div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
    <h2 align="center">Export MySQL data to Excel in PHP</h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>url</th>  
                         <th>img</th>  
                         <th>p</th>  
       <th>a</th>
       <th>h1</th>
       <th>h2</th>
       <th>h3</th>
       <th>h4</th>
       <th>h5</th>
       <th>h6</th>
       <th>span</th>

                    </tr>

     <?php
     while($row = mysqli_fetch_array($result))  
     {
        echo '  
       <tr>  
         <td>'.$row["url"].'</td>  
         <td>'.$row["img"].'</td>  
         <td>'.$row["p"].'</td>  
         <td>'.$row["a"].'</td>  
         <td>'.$row["h1"].'</td>
         <td>'.$row["h2"].'</td>
         <td>'.$row["h3"].'</td>
         <td>'.$row["h4"].'</td>
         <td>'.$row["h5"].'</td>
         <td>'.$row["h6"].'</td>
         <td>'.$row["span"].'</td>

       </tr>  
        ';  
     }
     ?>
    </table>
    <br />
    <form method="post" action="<?=plugin_dir_url(__FILE__)?>export_download.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form><?php

}